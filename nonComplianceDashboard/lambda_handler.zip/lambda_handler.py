import traceback
import boto3
import os

html_top = '''
    <!DOCTYPE html>
    <html lang='en'>
    <head>
        <meta charset='UTF-8'>
        <title>Non-Compliance Checker</title>
        <link rel='stylesheet' href='nonComplianceChecker.css'>
        <!-- Add style -->
        <style>
            table, th, td {
                border: 1px solid black;
                text-align: center;
            }
        </style>
    </head>
    <body>
        <div class='container'>
            <h1>Non-Compliance Checker</h1>
            <table>
                <tr>
                    <th>Creator</th>
                    <th>Resource Type</th>
                    <th>Resource Name</th>
                    <th>Creation Date</th>
                </tr>
'''
html_bottom = '''
        </table>
    </div>
</html>
'''

def create_row(creator, resource_type, resource_name, creation_date):
    return f'''
                <tr>
                    <td>{creator}</td>
                    <td>{resource_type}</td>
                    <td>{resource_name}</td>
                    <td>{creation_date}</td>
                </tr>
    '''


def lambda_handler(event, context):
    try:
        # Get data from the table
        dynamodb = boto3.resource('dynamodb')
        table = dynamodb.Table(os.environ['DYNAMODB_TABLE_NAME'])

        print('Attempting to read the data from the table.')
        response = table.scan()
        non_compliant_resources = response['Items']
        while 'LastEvaluatedKey' in response:
            response = table.scan(ExclusiveStartKey=response['LastEvaluatedKey'])
            non_compliant_resources.extend(response['Items'])

        # Generate the html file
        html = html_top
        for ncr in non_compliant_resources:
            html += create_row(ncr['creator'], ncr['resource_type'], ncr['resource_name'], ncr['creation_date'])
        html += html_bottom

        return {
            'statusCode': 200,
            'headers': {
                'Content-Type': 'text/html'
            },
            'body': html
        }


    except Exception:
        return {
            'statusCode': 500,
            'body': traceback.format_exc()
        }
