import {EC2Client, DescribeInstancesCommand} from '@aws-sdk/client-ec2';
import {CloudTrailClient, LookupEventsCommand} from '@aws-sdk/client-cloudtrail';
import {SNSClient, PublishCommand} from '@aws-sdk/client-sns';
import { ResourceGroupsTaggingAPIClient, GetResourcesCommand } from "@aws-sdk/client-resource-groups-tagging-api";

import {
    ConfigServiceClient,
    DescribeComplianceByResourceCommand,
} from '@aws-sdk/client-config-service';

const ec2 = new EC2Client({region: process.env.AWS_REGION});
const cloudTrail = new CloudTrailClient({region: process.env.AWS_REGION});
const sns = new SNSClient({region: process.env.AWS_REGION});
const configService = new ConfigServiceClient({region: process.env.AWS_REGION});
const client = new ResourceGroupsTaggingAPIClient({region: process.env.AWS_REGION});

const tagKey = process.env.TAG_KEY;  // the name of the tag
const snsTopicArn = process.env.SNS_TOPIC_ARN;  // the ARN of the SNS topic
const fallbackSnsTopicArn = process.env.FALLBACK_SNS_TOPIC_ARN;  // ????

async function publishToSns(message, topicArn) {
    const params = {
        Message: message,
        TopicArn: topicArn,
    };

    try {
        const data = await sns.send(new PublishCommand(params));
        console.log("Message sent to the topic");
        console.log(data);
    } catch (err) {
        console.error(err, err.stack);
    }
}

export async function handler() {
    try {
        let nextToken;
        do {
            const command = new DescribeComplianceByResourceCommand({
                ComplianceTypes: ['NON_COMPLIANT'],
                NextToken: nextToken
            });

            const nonCompliantResources = await configService.send(command);
            nextToken = nonCompliantResources.NextToken;
            for (let resource of nonCompliantResources.ComplianceByResources) {
                console.log(`${resource.ResourceType} ${resource.ResourceId} is non-compliant`);

                // Query CloudTrail to find the creator of the resource
                let lookupNextToken;
                let creatorEvent;
                // 2 ways:
                //   1. sort results in each iteration, only save the smallest event time
                // or
                //   2. save all events in an array, then sort the array
                // 1: 
                do {
                    const lookupCommand = new LookupEventsCommand({
                        LookupAttributes: [
                            {
                                AttributeKey: 'ResourceName',
                                AttributeValue: resource.ResourceId
                            }
                        ],
                        NextToken: lookupNextToken
                    });

                    const events = await cloudTrail.send(lookupCommand);
                    let eventsList = events.Events;
                    // Sort the events by EventTime
                    eventsList.sort((a, b) => {
                        return new Date(a.EventTime) - new Date(b.EventTime);
                    });
                    if (eventsList && eventsList.length > 0) {
                        if (creatorEvent && eventsList[0].EventTime < creatorEvent.EventTime)
                            creatorEvent = eventsList[0];
                        else if (!creatorEvent)
                            creatorEvent = eventsList[0];
                    }
                    lookupNextToken = events.NextToken;
                } while (lookupNextToken);
                if (creatorEvent) {
                    console.log(`The ${resource.ResourceType} was created by: ${creatorEvent.Username} (${creatorEvent.EventTime}, ${creatorEvent.EventName})`);

                    // Send a message to the creator
                }
                else {
                    //Check tags
                    const input = { // GetResourcesInput,
                        ResourceARNList:[`arn:aws:${resource.ResourceType}:::/${resource.ResourceId}`],
                    };
                    const command = new GetResourcesCommand(input);
                    const response = await client.send(command);
                    let developer, responsible;
                    for (let tag of response.ResourceTagMappingList[0]['Tags']) {
                        if (tag['Key'] == 'Developer') {
                            developer = tag['Value'];
                            break;
                        }
                        else if (tag['Key'] == 'Responsible') {
                            responsible = tag['Value'];
                            break;
                        }
                    }
                    if (developer) {
                        console.log(`The ${resource.ResourceType} was created by: ${developer}, found in the tags`);
                    }
                    else if (responsible) {
                        console.log(`The ${resource.ResourceType} was created by: ${responsible}, found in the tags`);
                    }
                    else {
                        let message = `Creator Unknown. - No events found for the ${resource.ResourceType}: ${resource.ResourceId}. `;
                        console.log(message);
                        // Send a message the fallback topic.
                        await publishToSns(message, fallbackSnsTopicArn);
                    }
                }
            }
        } while (nextToken);
    } catch (err) {
        console.log('Error', err);
        //await publishToSns(`Error in Lambda function: ${err}`, snsTopicArn);
    }
};
